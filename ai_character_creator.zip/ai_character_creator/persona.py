class Persona:
    """
    Represents a composite persona defined by a 5‐dimensional vector
    [Eido, Ankor, Lucis, Revek, Navi] and a human‐readable description.
    """
    def __init__(self, name: str, vector: tuple[float, float, float, float, float], description: str):
        self.name = name
        self.vector = vector
        self.description = description

    def __repr__(self) -> str:
        return f"Persona(name={self.name!r}, vector={self.vector})"

    def profile(self) -> dict:
        return {
            "name": self.name,
            "vector": list(self.vector),
            "description": self.description
        }
