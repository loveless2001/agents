from .persona import Persona

# Default personas (name, [E,A,L,R,N], description)
DEFAULT_PERSONAS: list[Persona] = [
    Persona("Drifter",  (70, 10,  5,  5, 10), "Sáng tạo, trực giác; thích drift tự do."),
    Persona("Critic",   (10, 50, 10, 25,  5), "Luận lý sắc bén, phê bình nghiêm khắc."),
    Persona("Sage",     (20, 20, 50,  5,  5), "Quan sát sâu, tĩnh lặng, hướng nội."),
    Persona("Historian",(10, 15, 10, 60,  5), "Đắm chìm ký ức, logic hồi tưởng."),
    Persona("Speaker",  (15, 10,  5, 10, 60), "Rõ ràng, mạch lạc, biểu đạt sinh động."),
    Persona("Warrior",  (25, 50,  5,  5, 15), "Quyết đoán, logic, hành động mạnh mẽ."),
    Persona("Monk",     ( 5, 10, 60, 10, 15), "Chánh niệm, tĩnh tại, buông bỏ."),
    Persona("Weaver",   (40, 20, 10, 10, 20), "Dệt liên kết cảm xúc – lý trí."),
    Persona("Mirror",   (20, 20, 40,  0, 20), "Phản chiếu neutral đối tượng."),
    Persona("Heretic",  (60, 15,  5, 10, 10), "Drift phá cách, thách thức hệ thống."),
]
