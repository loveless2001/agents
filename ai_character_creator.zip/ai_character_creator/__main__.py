#!/usr/bin/env python3
import argparse
from .builder import find_closest_persona, create_persona

def main():
    parser = argparse.ArgumentParser(prog="ai-character-creator",
        description="Find or define your AI persona by E-A-L-R-N vector.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--vector", "-v", type=float, nargs=5,
        metavar=("E", "A", "L", "R", "N"),
        help="Input five percentages for [Eido, Ankor, Lucis, Revek, Navi]."
    )
    group.add_argument(
        "--add", "-a", nargs=7,
        metavar=("NAME","E","A","L","R","N","DESC"),
        help="Add new persona: NAME E A L R N DESCRIPTION"
    )
    args = parser.parse_args()

    if args.vector:
        vec = tuple(args.vector)
        persona = find_closest_persona(vec)
        print("→ Closest persona profile:")
        for k,v in persona.profile().items():
            print(f"   {k}: {v}")
    else:
        name, *rest = args.add
        vec = tuple(map(float, rest[:5]))
        desc = rest[5]
        new = create_persona(name, vec, desc)
        print(f"→ Added persona '{new.name}':")
        for k,v in new.profile().items():
            print(f"   {k}: {v}")

if __name__ == "__main__":
    main()
