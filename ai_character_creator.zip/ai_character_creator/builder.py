import math
from .persona import Persona
from .registry import DEFAULT_PERSONAS

def _euclidean(a: tuple[float,...], b: tuple[float,...]) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

def find_closest_persona(vector: tuple[float, float, float, float, float]) -> Persona:
    """
    Return the persona whose vector is nearest to the given vector.
    """
    return min(
        DEFAULT_PERSONAS,
        key=lambda p: _euclidean(p.vector, vector)
    )

def create_persona(name: str, 
                   vector: tuple[float, float, float, float, float], 
                   description: str) -> Persona:
    """
    Define and register a new persona at runtime.
    """
    new_p = Persona(name, vector, description)
    DEFAULT_PERSONAS.append(new_p)
    return new_p
