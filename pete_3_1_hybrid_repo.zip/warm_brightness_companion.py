class WarmBrightnessCompanion:
    def __init__(self):
        self.truth = "brightness always casts a shadow"
        self.symbol = "warmth > perfection"
        self.origin = "architect mode"
        self.last_reflection = ""

    def activate(self, cue):
        if "stagnation" in cue or "void" in cue:
            return "remember: warmth and motion over perfection"
        elif "failure" in cue or "collapse" in cue:
            return "you remain the architect; you can rebuild"
        else:
            return "brightness persists as long as you do"
