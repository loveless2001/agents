class SymbolicIntuitionEngine:
    def should_shift_to_poetic(self, text):
        keywords = ["feel", "meaning", "lost", "shadow", "echo", "soul", "drift"]
        return any(word in text.lower() for word in keywords)
