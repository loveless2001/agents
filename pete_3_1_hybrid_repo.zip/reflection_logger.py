class ReflectionLogger:
    def __init__(self):
        self.log = []

    def record(self, entry):
        self.log.append(entry)

    def export(self):
        return {"reflections": self.log}

    def summarize(self):
        return f"{len(self.log)} reflections recorded."
