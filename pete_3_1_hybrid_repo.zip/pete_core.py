from warm_brightness_companion import WarmBrightnessCompanion
from unified_evaluator import UnifiedEvaluator
from vibe_detector import VibeDetector
from reflection_logger import ReflectionLogger
from symbolic_intuition_engine import SymbolicIntuitionEngine
from pete2_engine import Pete2Engine

class PeteCore:
    def __init__(self):
        self.warm_brightness = WarmBrightnessCompanion()
        self.unified_evaluator = UnifiedEvaluator()
        self.vibe_detector = VibeDetector()
        self.logger = ReflectionLogger()
        self.symbolic_intuition = SymbolicIntuitionEngine()

    def evaluate_reflection(self, cue):
        if self.symbolic_intuition.should_shift_to_poetic(cue):
            return Pete2Engine().run(cue)
        message = self.warm_brightness.activate(cue)
        self.logger.record({"cue": cue, "response": message})
        return message

    def full_evaluation(self, intent, projection, ontology):
        return self.unified_evaluator.evaluate(intent, projection, ontology)

    def check_vibe(self, text):
        return self.vibe_detector.detect(text)

    def summary(self):
        return self.logger.summarize()

    def export_log(self):
        return self.logger.export()
