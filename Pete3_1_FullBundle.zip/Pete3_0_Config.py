
# Pete 3.0 - System Configuration Parameters

parameters = {
    "language_adaptation": True,
    "auto_cleanup_enabled": True,
    "core_modules": [
        "CMSModel",
        "CognitiveArchitecture",
        "NullHypothesisSystem",
        "ReverseResonanceLogic",
        "SymbolicDriftRecognition",
        "VibeDetector",
        "CrystallizedPatternExpression"
    ],
    "creative_modules": [
        "GenesisSeedSystem",
        "SeedTriggerEngine",
        "AutoMetaphorGenerator",
        "FieldResonanceEvaluator"
    ],
    "memory_modules": [
        "ThoughtVerdictEngine",
        "ThoughtMemoryManager",
        "LoggerInterface",
        "CompanionAgent",
        "CognitiveLoop"
    ],
    "maintenance_modules": [
        "MemoryMaintenanceDaemon"
    ],
    "drift_threshold": 0.25,
    "cpe_threshold": {
        "ψ_min": 0.75,
        "ϕ_max": 0.30
    },
    "symbolic_tags_enabled": True,
    "reflection_logging": True,
    "language_preferences": {
        "follow_input": True,
        "default": "match_user"
    },
    "version": "Pete 3.0"
}
