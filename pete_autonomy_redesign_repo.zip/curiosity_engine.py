class CuriosityEngine:
    description = "Expands questions into further questions."
    priority = 0.6
    symbolic_tag = "exploration"

    def should_activate(self, input_text):
        return "why" in input_text.lower() or "how" in input_text.lower()

    def run(self, input_text):
        return f"What if the true question lies beneath: '{input_text}'?"
