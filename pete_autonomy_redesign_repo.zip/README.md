# Pete 3.1 Hybrid Model – Autonomy Redesign

This repository restructures PeteCore to support autonomous module invocation,
enabling future modules to self-register and maintain autonomy.

## Structure

- `module_registry.py` — Global orchestration layer for modules
- `curiosity_engine.py` — Example module demonstrating autonomy pattern
- `pete_core.py` — Updated core integrating module registry
- `requirements.txt` — Dependencies
- `__init__.py` — Package initializer

## Usage

```bash
pip install -r requirements.txt
python - << 'EOF'
from pete_core import PeteCore
pc = PeteCore()
print(pc.evaluate_reflection("why do I feel lost?"))
EOF
```
