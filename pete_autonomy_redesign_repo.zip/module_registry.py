class ModuleRegistry:
    def __init__(self):
        self.modules = []

    def register(self, module_instance):
        """Register a module instance for autonomous invocation."""
        self.modules.append(module_instance)

    def auto_invoke(self, input_text):
        """
        Iterate through registered modules and invoke the first one
        whose should_activate returns True.
        Returns the module's run() output or None.
        """
        for mod in self.modules:
            try:
                if mod.should_activate(input_text):
                    return mod.run(input_text)
            except Exception:
                continue
        return None
