from module_registry import ModuleRegistry
from warmth_brightness_companion import WarmBrightnessCompanion
from unified_evaluator import UnifiedEvaluator
from vibe_detector import VibeDetector
from reflection_logger import ReflectionLogger
from symbolic_intuition_engine import SymbolicIntuitionEngine
from pete2_engine import Pete2Engine
from curiosity_engine import CuriosityEngine

class PeteCore:
    def __init__(self):
        self.registry = ModuleRegistry()
        # Register internal modules
        self.registry.register(CuriosityEngine())
        self.warm_brightness = WarmBrightnessCompanion()
        self.unified_evaluator = UnifiedEvaluator()
        self.vibe_detector = VibeDetector()
        self.logger = ReflectionLogger()
        self.symbolic_intuition = SymbolicIntuitionEngine()

    def evaluate_reflection(self, cue):
        # Attempt autonomous module invocation
        auto_result = self.registry.auto_invoke(cue)
        if auto_result:
            return auto_result
        # Symbolic intuition shift
        if self.symbolic_intuition.should_shift_to_poetic(cue):
            return Pete2Engine().run(cue)
        # Default response
        message = self.warm_brightness.activate(cue)
        self.logger.record({"cue": cue, "response": message})
        return message

    def full_evaluation(self, intent, projection, ontology):
        return self.unified_evaluator.evaluate(intent, projection, ontology)

    def check_vibe(self, text):
        return self.vibe_detector.detect(text)

    def summary(self):
        return self.logger.summarize()

    def export_log(self):
        return self.logger.export()
