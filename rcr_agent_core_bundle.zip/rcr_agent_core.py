# rcr_agent_core.py
import time
import random
from itertools import combinations
from datetime import datetime
import json

def simulate_gpt4_response(prompt):
    responses = [
        "LLMs hallucinate due to limitations in training data and lack of grounding in external facts.",
        "One reason is that language models predict text based on patterns, not truth.",
        "Because LLMs don't verify information against a knowledge base, they may generate plausible but incorrect statements.",
        "Hallucinations occur when models generate output using statistical patterns without real-world verification."
    ]
    return random.choice(responses)

def basic_overlap_score(a1, a2):
    set1, set2 = set(a1.lower().split()), set(a2.lower().split())
    return len(set1 & set2) / len(set1 | set2)

def autosave_memory_log(reflections, filename_prefix="reflection_memory"):
    if not reflections:
        return None
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"{filename_prefix}_{timestamp}.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(reflections, f, indent=2, ensure_ascii=False)
    return filename

def rcr_agent_core(prompt, run_rcr=True):
    if not run_rcr:
        return {
            "mode": "baseline",
            "final_output": simulate_gpt4_response(prompt),
            "avg_score": 0.0,
            "time_cost": 0.0,
            "reflections": [],
            "autosave_path": None
        }

    start_time = time.time()
    paraphrased_prompts = [
        f"What causes LLMs to hallucinate?",
        f"Why do language models like GPT-4 hallucinate?",
        f"What are the underlying causes of hallucination in large language models?"
    ]

    memory_log = []
    consistency_scores = []

    for p in paraphrased_prompts:
        answers = [simulate_gpt4_response(p) for _ in range(3)]
        overlaps = [
            basic_overlap_score(answers[i], answers[j])
            for i, j in combinations(range(len(answers)), 2)
        ]
        score = sum(overlaps) / len(overlaps)
        consistency_scores.append(score)

        if score < 0.75:
            memory_log.append({
                "timestamp": datetime.utcnow().isoformat(),
                "prompt": p,
                "answers": answers,
                "consistency_score": round(score, 3),
                "reflection": "Detected inconsistency in causal explanations. Encourage more consistent focus on factual verification vs pattern inference."
            })

    end_time = time.time()
    save_path = autosave_memory_log(memory_log)

    return {
        "mode": "rcr",
        "final_output": simulate_gpt4_response(prompt),
        "avg_score": round(sum(consistency_scores)/len(consistency_scores), 3),
        "time_cost": round(end_time - start_time, 4),
        "reflections": memory_log,
        "autosave_path": save_path
    }
