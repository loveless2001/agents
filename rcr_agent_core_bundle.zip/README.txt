# RCR Agent Core

This is a lightweight simulation of the Recursive Consistency + SelfCheck + Reflexion module for evaluating prompts passed to large language models (LLMs) such as GPT-4o.

## Features
- Reformulates prompts to detect semantic instability
- Sample and score multiple outputs for consistency
- Trigger reflection if answers diverge significantly
- Persist reflection memory logs in JSON format
- Compare time cost of baseline vs full module

## Usage

```python
from rcr_agent_core import rcr_agent_core

result = rcr_agent_core("Why do LLMs hallucinate?", run_rcr=True)
print(result)
```
